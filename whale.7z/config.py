# config.py
DEFAULT_DELAY_FAN_TO_PUMP = 5  # seconds
DEFAULT_PUMP_PERIOD = 10       # seconds
DEFAULT_DELAY_PUMP_TO_FAN = 3  # seconds
DEFAULT_DELAY_BETWEEN_BLOWS = 15  # seconds
DEFAULT_TEMP_SETTING = 72     # Fahrenheit