# Whale Surrogate System
This project implements a control system for a Whale Surrogate, generating a serial, comma-delimited ASCII string for communication via USB or Ethernet.